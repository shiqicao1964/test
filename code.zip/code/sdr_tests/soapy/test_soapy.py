#!/usr/bin/env python3
import SoapySDR
from SoapySDR import *
import numpy as np

RATE = 1e6
FREQ = 915e6

# create device instance
args = dict(driver="bladerf")
sdr = SoapySDR.Device(args)

sdr.setSampleRate(SOAPY_SDR_RX, 0, RATE)
sdr.setFrequency(SOAPY_SDR_RX, 0, FREQ)

rxStream = sdr.setupStream(SOAPY_SDR_RX, SOAPY_SDR_CF32)

sdr.activateStream(rxStream)

buff = np.array([0]*1024, np.complex64)

ts = 0
for i in range(10):
    sr = sdr.readStream(rxStream, [buff], len(buff))
    print('ret:', sr.ret)
    print('flags:', sr.flags)
    print('ts delta:', sr.timeNs - ts)
    ts = sr.timeNs

sdr.deactivateStream(rxStream)
sdr.closeStream(rxStream)
