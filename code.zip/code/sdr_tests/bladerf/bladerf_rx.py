#!/usr/bin/env python3

from bladerf import _bladerf

devinfos = _bladerf.get_device_list()
device = "{backend}:device={usb_bus}:{usb_addr}".format(**devinfos[0]._asdict())

b = _bladerf.BladeRF(device)

rx_ch = _bladerf.CHANNEL_RX(0)
ch = b.Channel(rx_ch)
ch.frequency = 915e6
ch.sample_rate = 1e6
ch.gain = 40

b.sync_config(layout=_bladerf.ChannelLayout.RX_X1,
              fmt=_bladerf.Format.SC16_Q11,
              num_buffers=16,
              buffer_size=8192,
              num_transfers=8,
              stream_timeout=3500)

ch.enable = True

# receive buffer
bytes_per_sample = 4
buf = bytearray(1024*bytes_per_sample)
num_samples_read = 0

with open('iq.bin', 'wb') as outfile:
    while num_samples_read < 100000:
        num = len(buf)//bytes_per_sample
        b.sync_rx(buf, num)

        outfile.write(buf[:num*bytes_per_sample])
        num_samples_read += num

ch.enable = False

print ('done')
